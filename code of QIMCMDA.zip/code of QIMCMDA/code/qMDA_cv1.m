function qMDA_cv1()
str = importdata('miRNA-disease association data.xlsx');
[~,disease]=xlsread('disease name.xlsx');
[~,miRNA]=xlsread('miRNA name.xlsx');
% nd:the number of diseases
% nm:the number of miRNAs
% pp:the number of known diseae-miRNA associations
nd = 383;
nm = 495;
[pp,~] = size(str);
% FS:the functional similarity between m(i) and m(j)
% FSP:Functional similarity weighting matrix

FS = load('functional similarity matrix.txt');
FSP = load('functional similarity weighting matrix.txt');             
SS1 = load('disease semantic similarity matrix 1.txt');
SS2 = load('disease semantic similarity matrix 2.txt');
SS = (SS1+SS2)/2;
SSP = load('disease semantic similarity weighting matrix1.txt');
%interaction: adajency matrix for the disease-miRNA association network
%interaction(i,j)=1 means miRNA j is related to disease i

A = str;

for i =1:pp
        interaction(A(i,2),A(i,1)) = 1;
end
x=randperm(pp)';
T=1;
for cv=1:pp 
    cv
    % obtain training sample   
    interaction(A(cv,2),A(cv,1))=0;
%q-kernel similarity network construction
  [sdistd,sdistm] = SDIST(interaction,nd,nm);

%Inverse Multiquadric q-Kernel
  [kd,km] = PQD3(sdistd,sdistm,nd,nm,0.1,0.65);
%Distance into similarity network
 qd =(1- mapminmax(kd,0,1));
 qm =(1- mapminmax(km,0,1));
 sd=(qd+qd')/2;
 sm=(qm+qm')/2;
%Integrated similarity network
      [AM] = integratedsimilarity(FS,FSP,sm); 
      [AD] = integratedsimilarity(SS,SSP,sd);
% obtain the score of tested  disease-microbe interaction
 [score]=MYNMFKL(interaction,AD,AM,114);
 F = score;
% obtain the score of tested  disease-microbe interaction
finalscore=F(A(cv,2),A(cv,1));
% make the score of seed  disease-microbe interactions as zero
for i=1:nd
    for j=1:nm
        if interaction(i,j)==1
           F(i,j)=-10000;
        end
    end
end

% obtain the position of tested disease-microbe interaction as variable globalposition(1,cv),

[ll1,mm1]=size(find(F>=finalscore));
[ll2,mm2]=size(find(F>finalscore));
globalposition(1,cv)=ll2+1+(ll1-ll2-1)/2;
interaction(A(cv,2),A(cv,1))=1;
end

 save('globalposition.mat','globalposition');   
end