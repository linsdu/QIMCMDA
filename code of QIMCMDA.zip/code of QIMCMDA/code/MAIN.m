clear
str = importdata('miRNA-disease association data.xlsx');
[~,disease]=xlsread('disease name.xlsx');
[~,miRNA]=xlsread('miRNA name.xlsx');
% nd:the number of diseases
% nm:the number of miRNAs
% pp:the number of known diseae-miRNA associations
nd = 383;
nm = 495;
[pp,~] = size(str);
% FS:the functional similarity between m(i) and m(j)
% FSP:Functional similarity weighting matrix
% SS:the semantic similarity between d(i) and d(j).
% SSP:semantic similarity weighting matrix
%
FS = load('functional similarity matrix.txt');
FSP = load('functional similarity weighting matrix.txt');             
SS1 = load('disease semantic similarity matrix 1.txt');
SS2 = load('disease semantic similarity matrix 2.txt');
SS = (SS1+SS2)/2;
SSP = load('disease semantic similarity weighting matrix1.txt');
%interaction: adajency matrix for the disease-miRNA association network
%interaction(i,j)=1 means miRNA j is related to disease i

A = str;

for i =1:pp
        interaction(A(i,2),A(i,1)) = 1;
end

save interaction


 [sdistd,sdistm] = SDIST(interaction,nd,nm);
%q-kernel function
[kd,km] = PQD3(sdistd,sdistm,nd,nm,0.1,0.6);
sd =(1- mapminmax(kd,0,1));
qm =(1- mapminmax(km,0,1));
sd=(sd+sd')/2;
sm=(qm+qm')/2;
      [AM] = integratedsimilarity(FS,FSP,sm); 
      [AD] = integratedsimilarity(SS,SSP,sd);
%Matrix Completion 
[score]=MYNMFKL(interaction,AD,AM,100);
 allresult(disease,miRNA,interaction,score)