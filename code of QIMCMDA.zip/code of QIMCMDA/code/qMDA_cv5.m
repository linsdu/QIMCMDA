function qMDA_cv5()
%c=0.1,q=0.6
str = importdata('miRNA-disease association data.xlsx');
[~,disease]=xlsread('disease name.xlsx');
[~,miRNA]=xlsread('miRNA name.xlsx');
% nd:the number of diseases
% nm:the number of miRNAs
% pp:the number of known diseae-miRNA associations
nd = 383;
nm = 495;
[pp,~] = size(str);
% FS:the functional similarity between m(i) and m(j)
% FSP:Functional similarity weighting matrix
FS = load('functional similarity matrix.txt');
% FSP = load('functional similarity weighting matrix.txt');      
for i =1:495
    for j =1:495
        if FS(i,j)>0
           FSP(i,j) = 1;
        end
    end
end
SS1 = load('disease semantic similarity matrix 1.txt');
SS2 = load('disease semantic similarity matrix 2.txt');
SS = (SS1+SS2)/2;
%  SSP = load('disease semantic similarity weighting matrix1.txt');
for i =1:383
    for j =1:383
        if SS(i,j)>0
           SSP(i,j) = 1;
        end
    end
end


%interaction: adajency matrix for the disease-miRNA association network
%interaction(i,j)=1 means miRNA j is related to disease i

A = str;

for i =1:pp
        interaction(A(i,2),A(i,1)) = 1;
end
save interaction
x=randperm(pp)';
T=1;
% I=load('interaction.csv');
for cv=1:5
    load interaction interaction
    if cv<=5
        B=A(x((cv-1)*floor(pp/5)+1:floor(pp/5)*cv),:);
% obtain training sample
        for i=1:floor(pp/5)
        interaction(B(i,2),B(i,1))=0;
        end
    end




% q-kernel similarity network construction
  [sdistd,sdistm] = SDIST(interaction,nd,nm);
%Inverse Multiquadric q-Kernel
  [kd,km] = PQD3(sdistd,sdistm,nd,nm,0.1,0.6);
%Distance into similarity network
 qd =(1- mapminmax(kd,0,1));
 qm =(1- mapminmax(km,0,1));
sd=(qd+qd')/2;
sm=(qm+qm')/2;



%Integrated similarity network
      [AM] = integratedsimilarity(FS,FSP,sm); 
      [AD] = integratedsimilarity(SS,SSP,sd);

    F=MYNMFKL(interaction,AD,AM,100);
% F= score;
[size1B,size2B]=size(B);

for i=1:size1B
finalscore(i,1)=F(B(i,2),B(i,1));
end
% make the score of seed  disease-microbe interactions as zero
for i=1:nd
    for j=1:nm
        if interaction(i,j)==1
           F(i,j)=-10000;
        end
    end
end


for qq=1:size1B
% obtain the position of tested disease-microbe interaction as variable position(1,cv), 
[ll1,mm1]=size(find(F>=finalscore(qq)));
[ll2,mm2]=size(find(F>finalscore(qq)));
globalposition(1,T)=ll2+1+(ll1-ll2-1)/2;
T=T+1;
end

end
 save('globalposition.mat','globalposition');   
 
end
%AUC=positiontooverallauc()
