function [sm] = integratedsimilarity(FS,FSP,km)         
 a=0.015;
sm = (a*FS+(1-a)*km).*FSP+km.*(-(FSP-1));                        
end