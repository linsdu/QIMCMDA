This program can be opened by MATLAB 2014a. After opening it, you can run it directly by clicking
the left mouse button to find the running button and press it
result_qMDA_cv5:q-MDA 5-fold cross validation results
result_qMDA_cv1:q-MDA LOOCV results
MAIN:the prediction result of potential miRNA-disease association

