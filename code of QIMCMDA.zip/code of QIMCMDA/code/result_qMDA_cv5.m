

clear

for cv=1
    cv
qMDA_cv5()  
overallauc(cv)=positiontooverallauc();
AUC=positiontooverallauc()
end
save overallauc overallauc
a=mean(overallauc);
b=std(overallauc);
