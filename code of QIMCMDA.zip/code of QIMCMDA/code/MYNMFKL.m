% function [score] = MYNMFKL(V, X,Y,K)
% %KL-divergence
% F = size(V,1);
% T = size(V,2);
%   
% W = rand(F, K);
% % W = W./repmat(sum(W),F,1);
% H = rand(K, T);
%   
% ONES = ones(F,T);
%  
% for i=1:1000
%     H = H*Y -((W'*X*(V./(X*W*H*Y+eps))+W'*X*ONES))./(W'*X*ONES);
%     W = X*W-((V./(X*W*H*Y+eps))*Y*H'+ONES*Y*H')./(ONES*Y*H');
% end
%  score=(X*W)*(Y*H')';
% end
% function [score] = MYNMFKL(V, X,Y,K)
% %KL-divergence
% F = size(V,1);
% T = size(V,2);
%   
% W = rand(F, K);
% % W = W./repmat(sum(W),F,1);
% H = rand(K, T);
%   
% ONES = ones(F,T);
%  
% for i=1:1000
%     H = H .* (W'*X'*X*(V*Y./((X*W)*(H*Y)+eps))) ./ (W'*(X')*ONES);
%     W = W .* ((X*V./((X*W)*(H*Y)+eps))*Y*(Y*H')) ./(ONES*Y*H');
% end
%  score=(X*W)*(H*Y);
% end
function [score] = MYNMFKL(V,X,Y,K)
%KL-divergence
F = size(V,1);
T = size(V,2);
  
% rand('seed',0)
W = rand(F, K);
% W = W./repmat(sum(W),F,1);
H = rand(K, T);

ONES = ones(F,T);
% ONES=eye(F,T);
i=1;
while i<300
%     H = H .* (W'*X*( V./(X*W*H*Y+eps))) ./ (W'*X*ONES+eps);
%     W = W .* ((V./(X*W*H*Y+eps))*Y*H') ./(ONES*Y*H'+eps);
     H = H .* (W'*X*((V*Y)./(X*W*H*Y+eps))) ./(W'*X*ONES*Y+eps);
     W = W .* (((X'*V)./(X*W*H*Y+eps))*Y*H')./(X*ONES*Y*H'+eps);
     i=i+1;
end
score = X*W*H*Y;
end